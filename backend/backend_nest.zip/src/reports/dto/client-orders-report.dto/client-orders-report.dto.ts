export class ClientOrdersReportDto {
    startDate: Date; // Начальная дата
    endDate: Date; // Конечная дата
    clientIds: number[]; // Список клиентов
}
