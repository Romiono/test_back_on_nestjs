export class ReportFilterDto {
    date: Date; // Дата формирования отчета
}
